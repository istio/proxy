WebAssembly Extension Support

# C++ SDK

A C++ SDK is available including a docker image build environment. See api/wasm/cpp/README.md.

# Rust SDK

The Rust SDK is a WIP. See api/wasm/rust/README.md.
