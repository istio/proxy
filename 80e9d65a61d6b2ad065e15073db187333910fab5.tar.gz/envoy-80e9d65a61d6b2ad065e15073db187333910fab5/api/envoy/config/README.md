Protocol buffer definitions for Envoy's bootstrap, filter, and service configuration.

Visibility should be constrained to none or `//envoy/config/bootstrap/v2` by default.
